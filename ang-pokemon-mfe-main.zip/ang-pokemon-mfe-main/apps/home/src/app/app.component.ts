import { Component } from '@angular/core';

@Component({
  selector: 'ang-pokemon-mfe-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
})
export class AppComponent {
  title = 'home';
}

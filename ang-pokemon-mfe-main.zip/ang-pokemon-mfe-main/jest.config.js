module.exports = {
  projects: ['<rootDir>/apps/search', '<rootDir>/apps/home'],
};
